Name: Michelle Martinez

Note: I couldn't get the program running without adding "End" to the end of the text file. Other than that, everything works. My text file is included in the .zip file.
